# config.py - يحتوي على مفاتيح API والإعدادات العامة

OPENAI_API_KEY = "your_openai_api_key"
DEEPSEEK_API_KEY = "your_deepseek_api_key"

TWITTER_API_KEY = "XUZcwrPDaMI4QJYbLTcbeFmkV"
TWITTER_API_SECRET = "1kJWbJjgvlFcNgvelHnSoIJ2Bqw0GCLmbfrSsZ6Y0kp47hdZfP"
DISCORD_WEBHOOK_URL = "sk-1afd336e74d240a1ae23fe7ddbc2fa95
"
FACEBOOK_PAGE_ACCESS_TOKEN = "GGQVliQmdwdHU3SGc0NXhrS2k2NVhZANkRVSGwtUmhUclZAGYmFiUERiNzhEYmFwclhiSmRSZAFk4NnVobGtSdWNJMHBUZAHVidWdqYmpkY2t0TjZApamNQblcyVGZArdDJVSU5KXy11ZAkRpT01idTRaZAjVFZAk5zNFNSYjJ3Y01vbDVvbzhhZA0hsekZAKU19COHlSREhZAUmpJdFZAOOUsxaHpGQ1F1YTZA3"

TEXT_PROMPT_FILE = "prompts/text_prompt.txt"
IMAGE_PROMPT_FILE = "prompts/image_prompt.txt"

POST_INTERVAL_HOURS = 6  # كل كم ساعة يتم النشر؟
LOG_FILE = "output/logs.txt"