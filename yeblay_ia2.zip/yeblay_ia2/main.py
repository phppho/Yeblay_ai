# main.py - تشغيل الجدولة التلقائية

from utils.scheduler import start_scheduler

if __name__ == "__main__":
    start_scheduler()