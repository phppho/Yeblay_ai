# utils/scheduler.py - جدولة النشر التلقائي

import schedule
import time
from utils.text_generator import generate_text
from utils.image_generator import generate_image
from utils.social_media import post_all
from utils.logger import log_info

def job():
    """مهمة الجدولة - توليد النص، توليد الصورة، ونشر المحتوى"""
    text = generate_text()
    image_path = generate_image()
    
    if image_path:
        post_all(text, image_path)
        log_info("🎯 تم نشر منشور جديد بنجاح!")

# ضبط النشر كل 6 ساعات
schedule.every(6).hours.do(job)

def start_scheduler():
    """تشغيل الجدولة بشكل مستمر"""
    log_info("📅 بدأ الجدولة التلقائية...")
    while True:
        schedule.run_pending()
        time.sleep(1)