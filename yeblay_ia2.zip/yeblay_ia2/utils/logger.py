# utils/logger.py - وحدة تسجيل العمليات والأخطاء

import logging
import config

# إعداد ملف تسجيل العمليات
logging.basicConfig(
    filename=config.LOG_FILE,
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
)

def log_info(message):
    """تسجيل رسالة معلومات"""
    logging.info(message)
    print(f"✅ {message}")

def log_error(message):
    """تسجيل رسالة خطأ"""
    logging.error(message)
    print(f"❌ {message}")