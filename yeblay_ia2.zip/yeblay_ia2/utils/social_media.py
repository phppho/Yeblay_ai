# utils/social_media.py - النشر على تويتر، ديسكورد، وفيسبوك

import requests
import tweepy
import config
from utils.logger import log_info, log_error

def post_to_twitter(text, image_path):
    """نشر على تويتر"""
    try:
        auth = tweepy.OAuthHandler(config.TWITTER_API_KEY, config.TWITTER_API_SECRET)
        api = tweepy.API(auth)
        media = api.media_upload(image_path)
        api.update_status(status=text, media_ids=[media.media_id])
        log_info("✅ نُشر على تويتر")
    except Exception as e:
        log_error(f"❌ خطأ في تويتر: {e}")

def post_to_discord(text, image_path):
    """نشر على ديسكورد"""
    try:
        with open(image_path, "rb") as file:
            files = {"file": file}
            data = {"content": text}
            requests.post(config.DISCORD_WEBHOOK_URL, data=data, files=files)
        log_info("✅ نُشر على ديسكورد")
    except Exception as e:
        log_error(f"❌ خطأ في ديسكورد: {e}")

def post_to_facebook(text):
    """نشر على فيسبوك (النص فقط)"""
    try:
        url = "https://graph.facebook.com/v12.0/me/feed"
        data = {"message": text, "access_token": config.FACEBOOK_PAGE_ACCESS_TOKEN}
        requests.post(url, data=data)
        log_info("✅ نُشر على فيسبوك")
    except Exception as e:
        log_error(f"❌ خطأ في فيسبوك: {e}")

def post_all(text, image_path):
    """نشر على جميع المنصات"""
    post_to_twitter(text, image_path)
    post_to_discord(text, image_path)
    post_to_facebook(text)