# utils/image_generator.py - توليد الصور باستخدام DALL·E

import openai
import requests
import os
import config
from utils.logger import log_info, log_error

def load_prompt(file_path):
    """تحميل الـ Prompt من ملف نصي"""
    try:
        with open(file_path, "r", encoding="utf-8") as file:
            return file.read().strip()
    except Exception as e:
        log_error(f"خطأ في قراءة الـ Prompt: {e}")
        return "تصميم رقمي لعملة مشفرة"

def generate_image(filename="output/image.png"):
    """توليد صورة باستخدام DALL·E"""
    try:
        openai.api_key = config.OPENAI_API_KEY
        prompt = load_prompt(config.IMAGE_PROMPT_FILE)
        response = openai.Image.create(prompt=prompt, n=1, size="1024x1024")

        image_url = response["data"][0]["url"]
        
        # تحميل الصورة وحفظها
        img_data = requests.get(image_url).content
        os.makedirs("output", exist_ok=True)
        with open(filename, "wb") as handler:
            handler.write(img_data)

        log_info(f"تم توليد صورة: {filename}")
        return filename
    except Exception as e:
        log_error(f"خطأ في توليد الصورة: {e}")
        return None