# utils/text_generator.py - توليد المنشورات باستخدام DeepSeek

import requests
import config
from utils.logger import log_info, log_error

def load_prompt(file_path):
    """تحميل الـ Prompt من ملف نصي"""
    try:
        with open(file_path, "r", encoding="utf-8") as file:
            return file.read().strip()
    except Exception as e:
        log_error(f"خطأ في قراءة الـ Prompt: {e}")
        return "اكتب منشورًا تسويقيًا عن عملة Yeblay."

def generate_text():
    """توليد النصوص باستخدام DeepSeek"""
    try:
        headers = {"Authorization": f"Bearer {config.DEEPSEEK_API_KEY}", "Content-Type": "application/json"}
        prompt = load_prompt(config.TEXT_PROMPT_FILE)
        payload = {"model": "deepseek-chat", "messages": [{"role": "user", "content": prompt}]}
        response = requests.post("https://api.deepseek.com/v1/chat/completions", json=payload, headers=headers)

        if response.status_code == 200:
            log_info("تم توليد منشور باستخدام DeepSeek")
            return response.json()["choices"][0]["message"]["content"]
        else:
            raise Exception("استجابة غير متوقعة من DeepSeek")
    except Exception as e:
        log_error(f"خطأ في DeepSeek: {e}")
        return "🚀 Yeblay في صعود مستمر! هل أنت مستعد للاستثمار؟ 💰🔥"